<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <title>Références</title>
  </head>

  <body>
    
    <?php 
      require "articles.php"; 
    ?>
  
  </body>

</html>
